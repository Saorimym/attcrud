<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="index.css" />
    <title> Atividade PHP</title>
</head>

<body>
    <center>
        <td>
            <h1>Gerenciador de Telas do Restaurante</h1>
        </td>
    </center>
    <div class="container-tudo">

        <table>
            <tr>
                <td class="botoes"><button onclick="location.href = 'tela_pedidos/index_pedidos.php'">Tela de
                        Pedidos</button></td>
                <td class="botoes"><button onclick="location.href = 'tela_funcionarios/index_funcionarios.php'">Tela de
                        Funcionários</button></td>
                <td class="botoes"><button onclick="location.href = 'tela_cliente/index_cliente.php'">Tela de
                        Clientes</button></td>
            </tr>
        </table>
        </form>
    </div>
</body>

</html>